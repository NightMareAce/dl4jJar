# Legacy Spark Examples

These examples should be considered legacy/outdated as of 1.0.0-beta4.

Unlike the TinyImageNet and Patent Classifier examples, the examples in this directory do not use best practices for the
data pipelines and training (such as using gradient sharing instead of parameter averaging).
