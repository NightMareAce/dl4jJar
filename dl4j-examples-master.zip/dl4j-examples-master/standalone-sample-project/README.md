# standalone-sample-project

This directory: A simple stand-alone sample project, based on a single pom.xml file.

This can be used as a minimal starting point for your own projects.
