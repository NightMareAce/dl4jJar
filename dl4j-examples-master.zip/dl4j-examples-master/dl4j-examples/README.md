# Gradle Kotlin Examples

Open built-in Terminal from the Android Studio or IntelliJ IDEA. 
If you prefer, use the terminal app on your computer.
In the terminal window, `cd` to the project root directory `dl4j-examples` if not already in.
And then type `./gradlew NameOfExampleToRun` to run the examples as shown below.
(_you can use IDE's run-configuration green run button, if you like._)

MLPMnistSingleLayerExample
```
./gradlew MLPMnistSingleLayerExample
```

MLPMnistTwoLayerExample
```
./gradlew MLPMnistTwoLayerExample
```

etc.
